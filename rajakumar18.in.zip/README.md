# 🚀 RajaKumar18.in — GitHub Pages पर Deploy कैसे करें

## 📁 फाइलें
- `index.html` — पूरी Website (PWA, Player, Channel, Playlists, Admin)
- `manifest.json` — PWA Manifest (App Install के लिए)
- `sw.js` — Service Worker (Offline + Notifications)
- `README.md` — यह गाइड

---

## ✅ Step 1: GitHub पर Upload करें

1. [github.com](https://github.com) → New Repository
2. नाम: `rajakumar18-website` → Public → Create
3. **Upload files** → चारों files drag करें → Commit

---

## ✅ Step 2: GitHub Pages से Live करें

1. Repository → **Settings** → **Pages**
2. Source: `main` branch → `/ (root)` → **Save**
3. 2-3 मिनट बाद Live: `https://yourusername.github.io/rajakumar18-website`

---

## ✅ Step 3: rajakumar18.in Domain जोड़ें

1. GitHub Pages → Custom Domain: `rajakumar18.in` → Save
2. Domain registrar (GoDaddy/Namecheap) → DNS Settings:
   - CNAME record: `www` → `yourusername.github.io`
   - A records (GitHub IPs):
     - 185.199.108.153
     - 185.199.109.153
     - 185.199.110.153
     - 185.199.111.153
3. **Enforce HTTPS** ✓ (Free SSL!)

---

## ✅ Step 4: icon-192.png बनाएं

PWA के लिए 2 icon files बनाएं:
- `icon-192.png` (192×192 pixels)
- `icon-512.png` (512×512 pixels)

[favicon.io](https://favicon.io) पर जाएं → Text "RK" → Color #ff3d00 → Download करें

---

## ✅ Step 5: Google AdSense Apply करें

Website Live होने के बाद:
1. [adsense.google.com](https://adsense.google.com) → Get Started
2. `rajakumar18.in` डालें → Apply
3. Approval आने पर `index.html` में Ad code डालें

### ✅ AdSense Checklist (सब ready है):
- ✅ Privacy Policy page
- ✅ Terms & Conditions page  
- ✅ About Us page
- ✅ Contact Us page (Raja Kumar, 9682316132)
- ✅ SEO Meta Tags (title, description, keywords)
- ✅ JSON-LD Schema (WebSite + VideoObject)
- ✅ Open Graph + Twitter Card
- ✅ Canonical URL
- ✅ Mobile Responsive
- ✅ HTTPS (GitHub Pages free SSL)
- ✅ No copyright violation
- ✅ Original content structure

---

## 👑 Admin Panel
- Website के नीचे दाएं कोने में **RK** button
- ID: `9682316132` | Password: `968231`

## 📞 Contact
Raja Kumar | 9682316132 | rajahribabakumar@gmail.com
WhatsApp: https://whatsapp.com/channel/0029VbCHva3Ae5VxC8fpS51N
